# Aion2DPSMeter 0.15.2: session kit (build ad80377)

| File | What it does |
|---|---|
| `app\aion2dpsmeter.exe` | **The meter**. Keep `WebView2Loader.dll` next to it |
| `recorder\Record-Aion2.ps1` | **Recorder** |
| `recorder\a2-keep.exe` | Fast filter the recorder runs on stop (keep it next to the script) |
| `recorder\CHECKLIST.md` | What to do and what to type at the M marker |
| `probe\a2-capture-probe.exe` | Capture test, only when asked |

Requirement: **Npcap** (installed with Wireshark). WebView2 is built into Windows 10/11.

## Start

1. Task Manager → Details: end any old `aion2dpsmeter.exe`.
2. Recorder, in PowerShell from this folder, **before the game**:
   `powershell -ExecutionPolicy Bypass -File .\recorder\Record-Aion2.ps1 -Scenario S00-full-session -Notes "kit 0.15.2 ad80377"`
3. Meter: double-click `app\aion2dpsmeter.exe` ("Windows protected your PC" → More info → Run anyway).
   - **Ctrl+Shift+M** toggles click-through. Tray icon: Show/Hide, Inspector, Settings, Click-through, Quit.
4. Play. Follow `recorder\CHECKLIST.md` → "Next session".
5. Stop: **Q** in the recorder window (it says "fast filter" and finishes in seconds), then Quit the meter from the tray.

## Updates

From 0.7.0 the meter looks for a new version on GitHub (⚙ → "Check for updates", on by default) and shows a dot on ⚙ when there is one. **Update now** downloads it, checks it and restarts; the previous version stays as `app\aion2dpsmeter.prev.exe` (⚙ → "Roll back"). Nothing installs without your click. Keep this folder layout (`app\`, `recorder\`, `probe\`) so the recorder and probe are updated too.

## Send back

- The recorder zip (Drive, "Anyone with the link")
- Screenshots: our meter next to another meter after boss kills, and anything that looks wrong
- If the meter misbehaves: `%LOCALAPPDATA%\Aion2DPSMeter\logs\meter.log`
