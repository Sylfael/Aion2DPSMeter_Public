<#
.SYNOPSIS
    Records AION 2 game traffic for Aion2DPSMeter development (milestone M0).

.DESCRIPTION
    Passive capture only: uses Wireshark's dumpcap (with Npcap) to save traffic; it never sends,
    alters or injects anything and never touches the game process.

    How it works:
      1. A broad capture ("tcp and not port 443 and not port 80") starts on the default network
         adapter as soon as the script runs, so the login / zone-in burst of every game connection
         is kept, whatever port the game uses.
      2. While recording, the script polls the game process's TCP connections every 2 s and logs
         them to connections.csv.
      3. On stop, a2-keep.exe (next to this script; tshark if it is missing) keeps ONLY the
         game's connections (plus anything on port 13328) and,
         by default, strips the client->server payload (the game's own requests, which may carry
         a session token). The unfiltered capture is deleted.

    Output: one zip per session in -OutDir with game-only .pcapng files, meta.json (scenario, notes,
    markers, versions, hashes) and connections.csv.

    Keys while recording (in this console window):
      M  add a timestamped marker with a short note ("pull", "died", "swap ring")
      Q  stop recording and build the zip (Ctrl+C also stops and still builds the zip)

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\Record-Aion2.ps1 -Scenario S1-dummy-60s

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\Record-Aion2.ps1 -ListInterfaces
#>
[CmdletBinding(DefaultParameterSetName = 'Record')]
param(
    [Parameter(ParameterSetName = 'Record', Mandatory = $true)]
    [ValidateSet(
        'S00-full-session', 'S1-dummy-60s', 'S2-skill-walk', 'S3-boss-kill', 'S4-wipe-reset', 'S5-death',
        'S6-summons', 'S7-field-bosses', 'S8-lobby', 'S9-zone-changes', 'S10-buffs',
        'S11-gear-swap', 'S12-tickets-currency', 'S13-party-applicants', 'S14-inspect', 'S15-pet-souls', 'S99-free'
    )]
    [string]$Scenario,

    [Parameter(ParameterSetName = 'Record')] [string]$Region = '',
    [Parameter(ParameterSetName = 'Record')] [string]$Class = '',
    [Parameter(ParameterSetName = 'Record')] [string]$Notes = '',
    [Parameter(ParameterSetName = 'Record')] [string]$OutDir = (Join-Path $env:USERPROFILE 'Aion2Captures'),
    [Parameter(ParameterSetName = 'Record')] [string[]]$ProcessName = @('Aion2', 'AION2'),
    [Parameter(ParameterSetName = 'Record')] [int]$PollSeconds = 2,
    # Keep the client->server payload too (only needed to study whether that direction is encrypted).
    [Parameter(ParameterSetName = 'Record')] [switch]$KeepClientPayload,
    # Capture on every adapter (loopback, VPN/TUN, physical). Turned on automatically when an
    # accelerator (ExitLag, VPN, booster) is running or the game talks to a local proxy.
    [Parameter(ParameterSetName = 'Record')] [switch]$AllAdapters,

    [Parameter(ParameterSetName = 'List', Mandatory = $true)] [switch]$ListInterfaces,

    # Finish a session that was interrupted (window closed, crash): filter its raw-unfiltered
    # folder down to game traffic and build the zip. Pass the session folder path.
    [Parameter(ParameterSetName = 'Finish', Mandatory = $true)] [string]$FinishSession,

    [string]$Dumpcap = ''
)

$ErrorActionPreference = 'Stop'
$ScriptVersion = '0.6.1'
$BasePort = 13328
$BroadFilter = 'tcp and not port 443 and not port 80'
$ExcludedPorts = @(80, 443)

function Write-Info($msg) { Write-Host "[rec] $msg" -ForegroundColor Cyan }
function Write-Warn($msg) { Write-Host "[rec] $msg" -ForegroundColor Yellow }
function Write-Err($msg)  { Write-Host "[rec] $msg" -ForegroundColor Red }

# ---------------------------------------------------------------- prerequisites
function Find-WiresharkTool([string]$exe, [string]$override) {
    if ($override -and (Test-Path $override)) {
        $dir = Split-Path (Resolve-Path $override).Path
        $p = Join-Path $dir $exe
        if (Test-Path $p) { return $p }
    }
    foreach ($base in @($env:ProgramFiles, ${env:ProgramFiles(x86)})) {
        if ($base) {
            $p = Join-Path $base "Wireshark\$exe"
            if (Test-Path $p) { return $p }
        }
    }
    $cmd = Get-Command $exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    return $null
}

$dumpcapExe = Find-WiresharkTool 'dumpcap.exe' $Dumpcap
$tsharkExe = Find-WiresharkTool 'tshark.exe' $Dumpcap
# Fast filter (one pass per file, seconds for a long session); tshark is the fallback.
$keepExe = Join-Path $PSScriptRoot 'a2-keep.exe'
if (-not (Test-Path $keepExe)) { $keepExe = $null }
if (-not $dumpcapExe) {
    Write-Err 'dumpcap.exe not found. Install Wireshark (https://www.wireshark.org/download.html),'
    Write-Err 'keep "Npcap" ticked in the installer, then run this script again.'
    exit 1
}
if (-not (Get-Service -Name npcap -ErrorAction SilentlyContinue)) {
    Write-Err 'Npcap service not found. Re-run the Wireshark installer and tick "Install Npcap".'
    exit 1
}
if ($ListInterfaces) {
    & $dumpcapExe -D
    exit 0
}
if (-not $tsharkExe -and -not $keepExe) {
    Write-Err 'Neither a2-keep.exe (next to this script) nor tshark.exe (ships with Wireshark) was found.'
    Write-Err 'One of them is needed to keep only game traffic.'
    exit 1
}
if ($Host.Name -ne 'ConsoleHost') {
    Write-Err 'Run this from a normal PowerShell console window (not ISE or VS Code), so keys work.'
    exit 1
}

# ---------------------------------------------------------------- helpers
function Get-GamePids {
    @(Get-Process -Name $ProcessName -ErrorAction SilentlyContinue | ForEach-Object { $_.Id } | Select-Object -Unique)
}

function Get-GameConnections([int[]]$pids) {
    if (-not $pids -or $pids.Count -eq 0) { return @() }
    @(Get-NetTCPConnection -ErrorAction SilentlyContinue | Where-Object {
        ($pids -contains $_.OwningProcess) -and
        ($_.State -eq 'Established') -and
        ($ExcludedPorts -notcontains $_.RemotePort)
    })
}

function Test-Loopback([string]$ip) {
    return ($ip -eq '::1' -or $ip.StartsWith('127.'))
}

function Get-DefaultRouteDevice {
    $route = Get-NetRoute -DestinationPrefix '0.0.0.0/0' -ErrorAction SilentlyContinue |
        Sort-Object { $_.RouteMetric + $_.InterfaceMetric } | Select-Object -First 1
    if (-not $route) { return $null }
    $adapter = Get-NetAdapter -InterfaceIndex $route.InterfaceIndex -ErrorAction SilentlyContinue
    if (-not $adapter) { return $null }
    return "\Device\NPF_$($adapter.InterfaceGuid)"
}

$AcceleratorNames = @('ExitLag*', 'GearUP*', 'LagoFast*', 'Mudfish*', 'NoPing*', 'WTFast*', 'wireguard*',
    'openvpn*', 'Tailscale*', 'zerotier*', 'Clash*', 'mihomo*', 'sing-box*', 'ExpressVPN*', 'Razer Cortex*', 'UU*')

function Get-RunningAccelerators {
    @(Get-Process -Name $AcceleratorNames -ErrorAction SilentlyContinue | ForEach-Object { $_.ProcessName } | Select-Object -Unique)
}

function Get-AllNpcapDevices {
    # `dumpcap -D` lines look like: 1. \Device\NPF_{GUID} (Ethernet)  /  \Device\NPF_Loopback (...)
    $prev = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    $lines = @(& $dumpcapExe -D 2>$null)
    $ErrorActionPreference = $prev
    $devs = foreach ($l in $lines) { if ("$l" -match '(\\Device\\NPF_[^\s]+)') { $Matches[1] } }
    # loopback first, then the rest; at most 8 captures
    @(@($devs | Where-Object { $_ -like '*Loopback*' }) + @($devs | Where-Object { $_ -notlike '*Loopback*' })) |
        Select-Object -Unique | Select-Object -First 8
}

$script:allAdaptersOn = $false
function Enable-AllAdapters([string]$why) {
    if ($script:allAdaptersOn) { return }
    $script:allAdaptersOn = $true
    Write-Info "capturing on all adapters ($why)"
    foreach ($d in (Get-AllNpcapDevices)) { Start-Capture $d }
}

function Get-NpcapDevice([string]$localIp) {
    $addr = Get-NetIPAddress -IPAddress $localIp -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $addr) { return $null }
    $adapter = Get-NetAdapter -InterfaceIndex $addr.InterfaceIndex -ErrorAction SilentlyContinue
    if (-not $adapter) { return $null }
    return "\Device\NPF_$($adapter.InterfaceGuid)"
}

$captures = New-Object System.Collections.ArrayList   # @{ Device; Process; Pipe; Graceful }

function Start-Capture([string]$device) {
    foreach ($c in $captures) { if ($c.Device -eq $device) { return } }
    $idx = $captures.Count + 1
    $prefix = Join-Path $script:rawDir ('raw{0:D2}.pcapng' -f $idx)
    $errLog = Join-Path $script:sessionDir ('dumpcap{0:D2}.log' -f $idx)
    # Signal pipe: dumpcap stops cleanly (flushes and closes the pcapng) when we close it.
    $pipeName = "aion2rec-$PID-$idx"
    $pipe = New-Object System.IO.Pipes.NamedPipeServerStream($pipeName, [System.IO.Pipes.PipeDirection]::Out)
    $argLine = "-i `"$device`" -f `"$BroadFilter`" -b duration:60 -q -Z `"\\.\pipe\$pipeName`" -w `"$prefix`""
    $p = Start-Process -FilePath $dumpcapExe -ArgumentList $argLine -NoNewWindow -PassThru -RedirectStandardError $errLog
    Start-Sleep -Milliseconds 1500
    $graceful = $true
    if ($p.HasExited) {
        # Fallback: this dumpcap rejected the signal pipe; run without it (stop by kill).
        Write-Warn 'dumpcap did not accept the signal pipe; falling back to a plain capture'
        $pipe.Dispose(); $pipe = $null; $graceful = $false
        $argLine = "-i `"$device`" -f `"$BroadFilter`" -b duration:60 -q -w `"$prefix`""
        $p = Start-Process -FilePath $dumpcapExe -ArgumentList $argLine -NoNewWindow -PassThru -RedirectStandardError $errLog
    }
    [void]$captures.Add(@{ Device = $device; Process = $p; Pipe = $pipe; Graceful = $graceful })
    Write-Info "capture #$idx on $device ($BroadFilter)"
}

function Stop-Captures {
    foreach ($c in $captures) {
        if ($c.Pipe) { try { $c.Pipe.Dispose() } catch { } }
    }
    foreach ($c in $captures) {
        try {
            if (-not $c.Process.WaitForExit(6000)) {
                if ($c.Graceful) { Write-Warn "dumpcap $($c.Process.Id) did not stop by itself; killing it (last seconds may be lost)" }
                Stop-Process -Id $c.Process.Id -Force
            }
        } catch { }
    }
}

function Get-AnchorStreamTerms([string]$file) {
    # Content-based pass: any TCP stream carrying the ServerTimestamp anchor bytes
    # 0E 00 36 is a game stream, even if the 2 s poller never saw it (short login hops).
    # Keep its server->client side (the anchor's source port) and bare handshake packets.
    $prev = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    $rows = & $tsharkExe -r $file -Y 'tcp.payload contains 0e:00:36' -T fields -e tcp.stream -e tcp.srcport -E 'separator=,' 2>$null
    $ErrorActionPreference = $prev
    $terms = New-Object System.Collections.ArrayList
    foreach ($r in @($rows | Select-Object -Unique)) {
        $parts = "$r".Split(',')
        if ($parts.Count -eq 2 -and $parts[0] -match '^\d+$' -and $parts[1] -match '^\d+$') {
            if ($KeepClientPayload) { [void]$terms.Add("(tcp.stream == $($parts[0]))") }
            else { [void]$terms.Add("(tcp.stream == $($parts[0]) && (tcp.srcport == $($parts[1]) || tcp.len == 0))") }
        }
    }
    return $terms
}

function Get-GameFilter($endpoints, $extraTerms) {
    # Display filter for tshark: game server -> us always; us -> game server only without payload
    # unless -KeepClientPayload.
    $terms = New-Object System.Collections.ArrayList
    [void]$terms.Add("(tcp.srcport == $BasePort)")
    if ($KeepClientPayload) { [void]$terms.Add("(tcp.dstport == $BasePort)") }
    else { [void]$terms.Add("(tcp.dstport == $BasePort && tcp.len == 0)") }
    foreach ($e in $endpoints) {
        $ipf = if ($e.Ip.Contains(':')) { 'ipv6' } else { 'ip' }
        [void]$terms.Add("($ipf.src == $($e.Ip) && tcp.srcport == $($e.Port))")
        if ($KeepClientPayload) { [void]$terms.Add("($ipf.dst == $($e.Ip) && tcp.dstport == $($e.Port))") }
        else { [void]$terms.Add("($ipf.dst == $($e.Ip) && tcp.dstport == $($e.Port) && tcp.len == 0)") }
    }
    foreach ($t in $extraTerms) { [void]$terms.Add($t) }
    return ($terms -join ' || ')
}

function Get-PacketCount([string]$file) {
    $prev = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    $n = @(& $tsharkExe -r $file -T fields -e frame.number 2>$null).Count
    $ErrorActionPreference = $prev
    return $n
}

function Invoke-FastKeep($rawFiles) {
    # a2-keep.exe: same rules as the tshark filter, anchor streams found across the whole
    # session. Returns the kept packet count, or -1 when it failed (then tshark takes over).
    $argList = New-Object System.Collections.ArrayList
    [void]$argList.AddRange(@('--out-dir', $script:sessionDir, '--base-port', "$BasePort"))
    foreach ($e in $endpoints) {
        $ep = if ("$($e.Ip)".Contains(':')) { "[$($e.Ip)]:$($e.Port)" } else { "$($e.Ip):$($e.Port)" }
        [void]$argList.AddRange(@('--endpoint', $ep))
    }
    if ($KeepClientPayload) { [void]$argList.Add('--keep-client-payload') }
    # The raw folder, not every file: a long session has over a thousand ring files, and their
    # paths overflow the 32,767-character Windows command line ("filename or extension is too long").
    [void]$argList.Add($script:rawDir)
    $prev = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    $argArr = $argList.ToArray()
    $lines = @(& $keepExe @argArr 2>> (Join-Path $script:sessionDir 'a2-keep.log'))
    $code = $LASTEXITCODE
    $ErrorActionPreference = $prev
    $last = $lines | Where-Object { "$_" -match '^kept (\d+)$' } | Select-Object -Last 1
    if ($code -ne 0 -or -not $last) {
        Get-ChildItem -Path $script:sessionDir -Filter '*_game.pcap*' | Remove-Item -Force
        return -1
    }
    return [int64]("$last".Split(' ')[1])
}

function Complete-Session {
    # Filter raw captures to game traffic, write meta.json, build the zip. Uses script-scope state.
    $kept = 0
    $filters = New-Object System.Collections.ArrayList
    $rawFiles = @(Get-ChildItem -Path $script:rawDir -Filter '*.pcapng' | Sort-Object Name)
    $fast = -1
    if ($keepExe -and $rawFiles.Count -gt 0) {
        Write-Info "keeping only game traffic: $($rawFiles.Count) file(s), fast filter (don't close this window)"
        $fast = Invoke-FastKeep $rawFiles
        if ($fast -ge 0) {
            $kept = $fast
            [void]$filters.Add((Get-GameFilter $endpoints @('(anchor streams, whole session)')) + ' [a2-keep]')
        } else {
            Write-Warn 'fast filter failed (see a2-keep.log); using tshark instead'
        }
    }
    if ($fast -lt 0) {
        if (-not $tsharkExe) {
            Write-Err 'tshark.exe not found; the raw capture is kept. Run -FinishSession on this folder after fixing it.'
            return
        }
        Write-Info "keeping only game traffic: $($rawFiles.Count) file(s) to filter (a few seconds each; don't close this window)"
        $i = 0
        foreach ($raw in $rawFiles) {
            $i++
            Write-Host ("`r[rec] filtering {0}/{1}  (game packets kept so far: {2})   " -f $i, $rawFiles.Count, $kept) -NoNewline -ForegroundColor Cyan
            $filter = Get-GameFilter $endpoints (Get-AnchorStreamTerms $raw.FullName)
            [void]$filters.Add($filter)
            $out = Join-Path $script:sessionDir ($raw.BaseName + '_game.pcapng')
            $prev = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
            & $tsharkExe -r $raw.FullName -Y $filter -w $out 2>> (Join-Path $script:sessionDir 'tshark.log')
            $ErrorActionPreference = $prev
            if (Test-Path $out) {
                $n = Get-PacketCount $out
                if ($n -gt 0) { $kept += $n } else { Remove-Item -Force $out }
            }
        }
        Write-Host ''
    }
    if ($kept -gt 0) {
        Remove-Item -Recurse -Force $script:rawDir
        Write-Info "kept $kept game packets; the unfiltered capture was deleted"
    } else {
        Write-Warn "no game packets matched. The unfiltered capture is KEPT on disk (not zipped): $script:rawDir"
        Write-Warn 'Tell the owner; do not upload that folder (it holds non-game traffic).'
    }
    $filter = ($filters | Select-Object -First 1)

    $files = @(Get-ChildItem -Path $script:sessionDir -Filter '*_game.pcapng' | Sort-Object Name | ForEach-Object {
        [ordered]@{ name = $_.Name; bytes = $_.Length; sha256 = (Get-FileHash $_.FullName -Algorithm SHA256).Hash }
    })
    $dumpcapVersion = $null
    try {
        $ErrorActionPreference = 'Continue'
        $dumpcapVersion = (& $dumpcapExe -v 2>&1 | Select-Object -First 1) -as [string]
    } catch { } finally { $ErrorActionPreference = 'Stop' }

    $meta = [ordered]@{
        schema            = 'aion2dpsmeter-capture-v2'
        scriptVersion     = $ScriptVersion
        scenario          = if ($script:scenarioLabel) { $script:scenarioLabel } else { $Scenario }
        region            = $Region
        class             = $Class
        notes             = $Notes
        startUtc          = $startUtc.ToString('o')
        endUtc            = $endUtc.ToString('o')
        localUtcOffset    = ([TimeZoneInfo]::Local.GetUtcOffset($startUtc)).ToString()
        gameProcess       = if ($gameProc) { $gameProc.ProcessName } else { $null }
        gameVersion       = $gameVersion
        windows           = [Environment]::OSVersion.VersionString
        dumpcap           = $dumpcapVersion
        captureFilter     = $BroadFilter
        keptFilter        = $filter
        keptPackets       = $kept
        clientPayloadKept = [bool]$KeepClientPayload
        allAdapters       = [bool]$script:allAdaptersOn
        accelerators      = @(Get-RunningAccelerators)
        localProxySeen    = [bool]$warnedLoopback
        gracefulStop      = @($captures | ForEach-Object { $_.Graceful })
        markers           = @($markers)
        files             = $files
    }
    $meta | ConvertTo-Json -Depth 6 | Out-File -FilePath (Join-Path $script:sessionDir 'meta.json') -Encoding utf8

    $zip = Join-Path $OutDir "$sessionName.zip"
    $toZip = @(Get-ChildItem -Path $script:sessionDir -File | ForEach-Object { $_.FullName })
    # .NET zip: much faster than Compress-Archive on Windows PowerShell 5.1.
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    if (Test-Path $zip) { Remove-Item -Force $zip }
    $za = [System.IO.Compression.ZipFile]::Open($zip, 'Create')
    try {
        foreach ($f in $toZip) {
            [void][System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile(
                $za, $f, [System.IO.Path]::GetFileName($f), [System.IO.Compression.CompressionLevel]::Optimal)
        }
    } finally { $za.Dispose() }
    $zipMb = [math]::Round((Get-Item $zip).Length / 1MB, 1)

    Write-Host ''
    if ($files.Count -eq 0) { Write-Warn 'no game packets were kept (was the game connected while recording?)' }
    Write-Host "  Done: $zip ($zipMb MB)" -ForegroundColor Green
    Write-Host '  Upload it to your private Google Drive folder "Aion2Captures" and tell the owner the file name.' -ForegroundColor Green
    Write-Host '  It contains names of players near you: keep it private.' -ForegroundColor Yellow
}

# ---------------------------------------------------------------- finish an interrupted session
if ($FinishSession) {
    $script:sessionDir = (Resolve-Path $FinishSession).Path
    $script:rawDir = Join-Path $script:sessionDir 'raw-unfiltered'
    if (-not (Test-Path $script:rawDir)) { Write-Err "no raw-unfiltered folder in $script:sessionDir"; exit 1 }
    $sessionName = Split-Path $script:sessionDir -Leaf
    $OutDir = Split-Path $script:sessionDir -Parent
    $script:scenarioLabel = if ($sessionName -match '^aion2_(.+)_\d{8}-\d{6}Z$') { $Matches[1] } else { 'unknown' }
    $Region = ''; $Class = ''; $Notes = 'finished later with -FinishSession'
    $endpoints = New-Object System.Collections.ArrayList
    $connLog = Join-Path $script:sessionDir 'connections.csv'
    if (Test-Path $connLog) {
        foreach ($row in (Import-Csv $connLog)) {
            $r = "$($row.remote)"; $cut = $r.LastIndexOf(':')
            if ($cut -gt 0) { [void]$endpoints.Add(@{ Ip = ($r.Substring(0, $cut) -replace '%.*$', ''); Port = $r.Substring($cut + 1) }) }
        }
    }
    $markers = New-Object System.Collections.ArrayList
    $rawTimes = @(Get-ChildItem -Path $script:rawDir -Filter '*.pcapng' | Sort-Object LastWriteTime)
    $startUtc = if ($rawTimes.Count) { $rawTimes[0].CreationTimeUtc } else { (Get-Date).ToUniversalTime() }
    $endUtc = if ($rawTimes.Count) { $rawTimes[-1].LastWriteTimeUtc } else { (Get-Date).ToUniversalTime() }
    $gameProc = $null; $gameVersion = $null; $warnedLoopback = $false
    Write-Info "finishing interrupted session: $script:sessionDir"
    Complete-Session
    exit 0
}

# ---------------------------------------------------------------- session setup
if (-not $Region) { $Region = Read-Host 'Region (eu / nae / naw / sa / asia / kr / tw)' }
if (-not $Class)  { $Class  = Read-Host 'Class and level you are playing (e.g. "Chanter 45")' }
if (-not $Notes)  { $Notes  = Read-Host 'Short notes (party size, dungeon, gear test details) - Enter to skip' }

$startUtc = (Get-Date).ToUniversalTime()
$stamp = $startUtc.ToString('yyyyMMdd-HHmmss')
$sessionName = "aion2_${Scenario}_${stamp}Z"
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$script:sessionDir = Join-Path $OutDir $sessionName
$script:rawDir = Join-Path $script:sessionDir 'raw-unfiltered'
New-Item -ItemType Directory -Force -Path $script:rawDir | Out-Null
$connLog = Join-Path $script:sessionDir 'connections.csv'
'utc,pid,local,remote,event' | Out-File -FilePath $connLog -Encoding utf8

$endpoints = New-Object System.Collections.ArrayList   # @{ Ip; Port }
$markers = New-Object System.Collections.ArrayList
$seen = @{}
$gameProc = $null; $gameVersion = $null
$warnedLoopback = $false

Write-Info "session folder: $script:sessionDir"
$baseDevice = Get-DefaultRouteDevice
if (-not $baseDevice) { Write-Err 'could not find the default network adapter'; exit 1 }

try {
    Start-Capture $baseDevice
    $accel = Get-RunningAccelerators
    if ($accel.Count -gt 0) { Enable-AllAdapters "accelerator running: $($accel -join ', ')" }
    elseif ($AllAdapters) { Enable-AllAdapters '-AllAdapters' }
    Write-Info 'waiting for the game (best: start this before launching the game)...'

    $running = $true
    $lastPoll = [DateTime]::MinValue
    $announced = $false
    while ($running) {
        if (((Get-Date) - $lastPoll).TotalSeconds -ge $PollSeconds) {
            $lastPoll = Get-Date
            $pids = Get-GamePids
            if ($pids.Count -gt 0 -and -not $gameProc) {
                $gameProc = Get-Process -Id $pids[0]
                try { $gameVersion = (Get-Item $gameProc.Path).VersionInfo.FileVersion } catch { }
                Write-Info "game process: $($gameProc.ProcessName) (pid $($pids -join ', ')) version $gameVersion"
                Write-Host ''
                Write-Host '  Recording. Keys in THIS window:  M = marker   Q = stop' -ForegroundColor Green
                Write-Host '  Tip: wait ~10 s after the scenario ends before pressing Q.' -ForegroundColor Green
                Write-Host ''
                $announced = $true
            }
            foreach ($c in (Get-GameConnections $pids)) {
                $k = "$($c.LocalAddress):$($c.LocalPort)>$($c.RemoteAddress):$($c.RemotePort)"
                if ($seen.ContainsKey($k)) { continue }
                $seen[$k] = $true
                $now = (Get-Date).ToUniversalTime().ToString('o')
                "$now,$($c.OwningProcess),$($c.LocalAddress):$($c.LocalPort),$($c.RemoteAddress):$($c.RemotePort),new" |
                    Out-File -FilePath $connLog -Append -Encoding utf8
                [void]$endpoints.Add(@{ Ip = ($c.RemoteAddress -replace '%.*$', ''); Port = $c.RemotePort })
                if ((Test-Loopback $c.RemoteAddress) -or (Test-Loopback $c.LocalAddress)) {
                    if (-not $warnedLoopback) {
                        Write-Info 'game talks to a local proxy (ExitLag / VPN / booster): also capturing loopback'
                        $warnedLoopback = $true
                    }
                    Enable-AllAdapters 'local proxy seen'
                    continue
                }
                Write-Info "game connection: $k"
                $dev = Get-NpcapDevice $c.LocalAddress
                if ($dev -and $dev -ne $baseDevice) { Start-Capture $dev }   # game on another adapter
            }
        }
        if ([Console]::KeyAvailable) {
            $key = [Console]::ReadKey($true)
            switch ($key.Key) {
                'Q' { $running = $false }
                'M' {
                    $t = (Get-Date).ToUniversalTime()
                    $note = Read-Host 'marker note (Enter = none)'
                    [void]$markers.Add([ordered]@{ utc = $t.ToString('o'); note = $note })
                    Write-Info "marker #$($markers.Count) at $($t.ToString('HH:mm:ss'))Z  $note"
                }
            }
        }
        Start-Sleep -Milliseconds 200
    }
}
finally {
    # Runs on Q and on Ctrl+C: stop cleanly, keep only game traffic, package.
    # A second Ctrl+C must not abort packaging.
    try { [Console]::TreatControlCAsInput = $true } catch { }
    Write-Info 'stopping captures (up to ~6 s each)...'
    Stop-Captures
    $endUtc = (Get-Date).ToUniversalTime()

    Complete-Session
}
