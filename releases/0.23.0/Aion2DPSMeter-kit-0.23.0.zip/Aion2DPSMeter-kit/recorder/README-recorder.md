# Recording AION 2 traffic (milestone M0)

Goal: a handful of short, labelled recordings of real game traffic. We use them to check the protocol spec and to build the test corpus for the meter. Nothing gets built until these exist.

**Time needed:** 15 min setup, then 5–15 min per scenario. Start with the 4 ⭐ scenarios.

---

> **What to record next:** `CHECKLIST.md` (events to do and what to type at the M marker).
>
> Handing the recorder to friends? Give them `Record-Aion2.ps1` + `FRIENDS.md` (plain-language guide with the privacy and account-risk notes).

## 1. One-time setup (Windows)

1. **Install Wireshark** from <https://www.wireshark.org/download.html> (Windows x64 installer).
   - In the installer, keep **"Install Npcap"** ticked.
   - In the Npcap step, leave **"Restrict Npcap driver's access to Administrators only"** *unticked*, so no admin rights are needed.
   - We only use its command-line part (`dumpcap`). You never need to open Wireshark itself.
2. **Get the recorder:** copy `Record-Aion2.ps1` from this folder to e.g. `C:\Aion2Rec\`. Read it first if you like: it only starts `dumpcap` and writes files.
3. **ExitLag / VPN / ping boosters are OK.** The recorder detects them and then captures on every adapter (including loopback), and keeps only the game's streams. If you can, also record one session *without* ExitLag: comparing the two shows how ExitLag routes the traffic, which the meter needs to know.
4. **Make a private Google Drive folder** called `Aion2Captures`. That's where the zips go.

Check that it works (lists your network adapters):

```powershell
cd C:\Aion2Rec
powershell -ExecutionPolicy Bypass -File .\Record-Aion2.ps1 -ListInterfaces
```

`-ExecutionPolicy Bypass` applies to this one run only and changes no system setting.

## 2. Recording a scenario

1. Start AION 2 and stop at **character select** (best), or anywhere in game.
2. Open PowerShell in `C:\Aion2Rec` and run, picking the scenario name from §3:

   ```powershell
   powershell -ExecutionPolicy Bypass -File .\Record-Aion2.ps1 -Scenario S1-dummy-60s
   ```

3. Answer three quick questions: region, class + level, notes.
4. Play the scenario. While recording, in the **PowerShell window**:
   - **M** = add a marker with a short note ("pull", "died", "swapped ring"). Markers give us ground-truth timestamps.
   - **Q** = stop. Wait ~10 s after the scenario ends before pressing Q. Ctrl+C also stops and still builds the zip.
5. The script prints the zip path (in `%USERPROFILE%\Aion2Captures\`). **Upload the zip to the Drive folder** and tell me the file name. I'll pull and check it from here.

**Optional, but very helpful:** record your screen with OBS at the same time, with the in-game clock or Windows clock visible. Video lets us check damage numbers, buff icons and deaths against the decoded data.

## 2b. Easiest option: one long session while you play normally

Run the recorder **before launching the game** with `-Scenario S00-full-session`, then play as usual. Everything the game sends during the session is kept: zone-ins, combat, deaths, party and lobby, pet snapshot at login, tickets. While playing, press **M** (in the PowerShell window) with a 2–3 word note whenever something notable happens: "pull X", "died", "applicant", "pet soul", "world map". Markers turn hours of traffic into findable moments.

What a normal session will **not** catch unless you do it on purpose:
- **Party applicants (S13):** only if you post a recruit and people apply.
- **Field-boss timers (S7):** the server sends them when you open the world map, so open it once or twice.
- **Clean baselines (S1/S2):** a 60 s solo dummy and a "each skill once, in order" walk make decoding much easier. Five minutes at a dummy is worth it.
- **Pet snapshot (S15):** sent only at login, so the recorder must already be running when you log in.

ExitLag/VPN on or off both work (see §1). Long sessions are fine: files rotate every minute and only game traffic is kept, roughly tens of MB per hour.

## 3. Scenarios

| # | Name (`-Scenario`) | Priority | What to do | What to note (markers / notes) |
|---|---|---|---|---|
| S1 | `S1-dummy-60s` | ⭐ | Solo on a training dummy: ~60 s of your normal rotation, then stop attacking for 10 s | Note any buffs or food. **Screenshot your character stat sheet** before starting |
| S2 | `S2-skill-walk` | ⭐ | On a dummy, use **each skill once, in a fixed order, ~3 s apart**. Write the order in the notes | Skill order list; press M before each skill if you can |
| S3 | `S3-boss-kill` | ⭐ | A normal dungeon run with a party, through at least one boss kill | Dungeon name and difficulty, party classes; M at each pull and kill |
| S5 | `S5-death` | ⭐ | Die once on purpose (to a mob or a boss mechanic), then resurrect | M at the death, plus what killed you |
| S4 | `S4-wipe-reset` | | A boss pull that wipes or resets (leash or run out) | M at pull and at the reset |
| S6 | `S6-summons` | | If you or a party member plays Elementalist or another summon class: dummy or boss with summons active | Summon names |
| S7 | `S7-field-bosses` | | In an open-world map: open the world map and the field-boss timers, wait 2–3 min, open them again | Map name; screenshot of the timers |
| S8 | `S8-lobby` | | Create or join a dungeon room (party finder), do a ready check, leave | Room settings |
| S9 | `S9-zone-changes` | | Teleport between 2–3 places, enter and leave an instance | M at each zone change |
| S10 | `S10-buffs` | | Use a potion, food, a scroll; let a party member buff you; cancel a buff | M + buff name each time |
| S11 | `S11-gear-swap` | | **Stat sheet screenshot** → swap one gear piece → screenshot → swap back → screenshot | Which item and slot. Feeds the stat-ID check for aion2-tools too |
| S12 | `S12-tickets-currency` | | Open the ticket/energy UI; buy something cheap with Kinah | Kinah before/after, ticket counts |
| S13 | `S13-party-applicants` | ⭐ (party checker) | Post a party recruit (party finder) and wait until **2–3 players apply**; also join someone else's room once | M when each applicant appears; their names are in the capture, so keep it private |
| S14 | `S14-inspect` | | Inspect 2–3 players (view character) | M + name each time |
| S15 | `S15-pet-souls` | ⭐ (pet tracker) | **Start the recorder before launching the game.** Log in, screenshot your pet boards, farm until one pet soul drops, unlock or level up a pet, open the Black Cloud merchant's Special / Pets tabs (buy and use one cheap card if you can), change map twice, then log into a second character and back | M at each step; note which pet got the soul and its count before/after |
| — | `S00-full-session` | ⭐ easiest | Play normally for as long as you like (see §2b) | M + short note at notable moments |
| — | `S99-free` | | Anything else interesting | Describe in notes |

Order of value: S1 → S2 → S3 → S5 → **S13** (needed for the party checker on NA West) → S11 → the rest.

## 4. Privacy (read once)

- During recording, dumpcap captures all TCP traffic except web ports 80/443 on your main network adapter. That is the only way to keep the first seconds of each game connection (the zone-in data). **When you stop, the script keeps only the game's connections** (found from the game process, plus port 13328) and **deletes the unfiltered capture** before zipping.
- By default it also **removes the payload of what your PC sends to the game** (the game's own requests, which may include a session token). Only the server's replies and the TCP handshake are kept. `-KeepClientPayload` turns this off; only use it if I ask.
- The game traffic still contains **names, classes and CP of players around you**, and probably **chat messages**. Avoid private chats during recordings, and keep the zips private (Drive, not public links).
- Recordings are **never committed** to any repository. Test fixtures in the repo are synthetic.

## 5. Account risk

NCSOFT's policy names packet sniffers as unauthorized programs. Wireshark/Npcap is generic, passive and widely used, but the risk is not zero, and it's your call. Recording sessions are short and send nothing to the game.

## 6. Troubleshooting

| Problem | Fix |
|---|---|
| Window closed / PC crashed before "Done" | `-FinishSession "<session folder>"` filters the leftover `raw-unfiltered` folder and builds the zip. Never send the unfiltered folder |
| `dumpcap.exe not found` | Install Wireshark (§1), or pass `-Dumpcap "D:\path\dumpcap.exe"` |
| `Npcap service not found` | Re-run the Wireshark installer and tick Npcap |
| "running scripts is disabled" | Use the `powershell -ExecutionPolicy Bypass -File ...` form shown above |
| Script never shows "game process" | The process name may differ. Look at the name in Task Manager → Details (without `.exe`) and pass it, e.g. `-ProcessName Aion2-Win64-Shipping` |
| `tshark.exe not found` | Put `a2-keep.exe` (from the kit) next to the script, or re-run the Wireshark installer with default components |
| Stopping takes minutes | Put `a2-keep.exe` next to `Record-Aion2.ps1` (v0.6+): the recorder then filters in seconds instead of running tshark several times per minute of capture |
| "Run this from a normal PowerShell console" | Open **Windows PowerShell** from the Start menu (not ISE or VS Code) |
| "dumpcap did not accept the signal pipe" | Harmless: recording works, but the last seconds before Q may be lost. Wait ~60 s before pressing Q |
| "capturing on all adapters" | Normal with ExitLag/VPN: the recorder captures loopback and tunnel adapters too. If the zip ends up with no game packets, record once with ExitLag off and send both |
| Zip is tiny (< 50 KB) | Probably no game connection was captured. Send it anyway with a note; the connections list inside tells us why |

## 7. For the developer: checking a capture

```bash
python3 -I tools/capture/check_capture.py aion2_S1-dummy-60s_*.zip [--dump 0438] [--json report.json]
```

It prints per-flow health (share of bytes that frame cleanly and share of catalogued opcodes), anchors (ServerTimestamp) and clock skew, LZ4 bundle success, an opcode histogram, and hex dumps of chosen opcodes. A flow reported as "NO KNOWN OPCODES" or "NO FRAMING" is not plaintext game framing (other traffic, or encrypted). To study the client→server direction, record with `-KeepClientPayload`.
