# Aion2DPSMeter 0.23.0: session kit (build ab73f5b)

| File | What it does |
|---|---|
| `app\aion2dpsmeter.exe` | **The meter**. Keep `WebView2Loader.dll` next to it |
| `recorder\Record-Aion2.ps1` | **Recorder** |
| `recorder\a2-keep.exe` | Fast filter the recorder runs on stop (keep it next to the script) |
| `recorder\CHECKLIST.md` | What to do and what to type at the M marker |
| `probe\a2-capture-probe.exe` | Capture test, only when asked |
| `NOTICE.txt`, `THIRD-PARTY-NOTICES.txt` | The terms of this private build, and the licences of the software and data it uses |
| `BUILDINFO.txt` | How this kit was built (versions, hashes) |

Requirement: **Npcap** (installed with Wireshark). WebView2 is built into Windows 10/11.

## Start

1. Task Manager → Details: end any old `aion2dpsmeter.exe`.
2. Recorder, in PowerShell from this folder, **before the game**:
   `powershell -ExecutionPolicy Bypass -File .\recorder\Record-Aion2.ps1 -Scenario S00-full-session -Notes "kit 0.23.0 ab73f5b"`
3. Meter: double-click `app\aion2dpsmeter.exe` ("Windows protected your PC" → More info → Run anyway).
   - **Ctrl+Shift+M** toggles click-through. The overlay's footer has one button per window (Party, Fight details, Tracker, Gear; Tracker has the World, Tickets and Pets tabs, Fight details a Records tab), then **More** (···: every window by name, Copy as image, Reset fight, Hide overlay, the quick settings, Quit) and click-through. There is no ×: Hide overlay and Quit are in More and the tray.
   - Tray icon: Show/Hide overlay, the windows by the same names, Click-through, Boss fights only, Reset windows (unstick), Quit.
4. Play. Follow `recorder\CHECKLIST.md` → "Next session".
5. Stop: **Q** in the recorder window (it says "fast filter" and finishes in seconds), then Quit the meter from the tray.

## Updates

The meter looks for a new version on GitHub 5 s after it starts, then every 6 hours (More → Settings → About → "Check for updates", on by default), and says so in the overlay and the tray when there is one. **Update now** downloads it, checks it and restarts; the previous version stays as `app\aion2dpsmeter.prev.exe` (Settings → About → "Roll back"). From 0.21.0, if the new version does not finish starting within 90 s, the meter puts the previous one back by itself and tells you. Nothing installs without your click. Keep this folder layout (`app\`, `recorder\`, `probe\`) so the recorder and probe are updated too.

## If the meter will not start

1. Check the tray: it may already be running. Only one meter runs at a time.
2. After an update: start `app\aion2dpsmeter.prev.exe` (the previous version); Settings → About → **Roll back** makes it the main one again.
3. If that fails too: end every `aion2dpsmeter.exe` in Task Manager, then in `app\` rename `aion2dpsmeter.exe` → `aion2dpsmeter.bad.exe`, `aion2dpsmeter.prev.exe` → `aion2dpsmeter.exe` (and `WebView2Loader.prev.dll` → `WebView2Loader.dll` if it is there), and start it.
4. Send `%LOCALAPPDATA%\Aion2DPSMeter\logs\meter.log` and `meter.prev.log`.

## Send back

- The recorder zip (Drive, "Anyone with the link")
- Screenshots: our meter next to another meter after boss kills, and anything that looks wrong
- If the meter misbehaves: `%LOCALAPPDATA%\Aion2DPSMeter\logs\meter.log`
