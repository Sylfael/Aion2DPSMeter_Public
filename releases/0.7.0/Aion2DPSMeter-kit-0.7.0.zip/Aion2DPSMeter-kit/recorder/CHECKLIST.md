# Recording checklist

Things to do in future sessions so the meter can learn them. Press **M** in the recorder window and type the marker text shown. Do what fits your session and skip the rest; tick a box when done (or just tell the owner).

Start every session the same way: recorder **before launching the game** (`-Scenario S00-full-session`), optionally the probe too (`a2-capture-probe.exe --seconds 600 > probe.txt`).

## Next session (most useful)

- [ ] **Our meter side by side with another meter** on 2–3 bosses, one screenshot each after the kill (sessions 4 and 5 have no other-meter numbers)
- [ ] **Decline an applicant** while leading a room. Marker: `declined`
- [ ] **Leave a party you don't lead.** Marker: `I left party`
- [ ] **A member leaves on their own.** Marker: `left`
- [ ] Press **M** at each boss pull: `pull <boss>`. It makes the fights easy to find
- [ ] If the meter shows anything odd, screenshot it and send `%LOCALAPPDATA%\Aion2DPSMeter\logs\meter.log`

Done 2026-11-05: dummy 60 s, open-world mobs, stat sheets, world map, probe, buffs, pet soul, merchant, expiry, kick, Horn Den ×5, Shattered Arkanis ×3, Nightmare Altar Hard, character swaps.

## Nightmare and dungeon bosses

- [ ] On entering: `nightmare lvl <n>`
- [x] Each boss: `pull <boss>` / `<boss> dead`, and the DPS other meters show if you see it: `<boss> other meter <dps>` (2026-11-05 part 2: Zikel's Apparition 37.32k, Furious Feruk ×2)
- [ ] Open-world elite (like Krosch): `elite <name> dead`
- [ ] A Nightmare or dungeon run with a **party** (not solo), with the other meter's numbers
- [ ] If the meter shows decode errors: hover its status line and note the opcodes listed (`decode errors 07 E3`)

## Party and applicants (applicant inspector)

You must be the **room leader**, since applications reach only the leader.

- [ ] **Decline an applicant.** Marker: `declined` (see Next session)
- [x] **Let an application expire**: do nothing for 30 s. Marker: `expired?`
- [x] **Kick a member on purpose.** Marker: `kicked`
- [ ] **A member leaves on their own.** Marker: `left`
- [ ] **Leave a party** yourself. Marker: `I left party`
- [ ] **Cross-server room**: someone from another server joins. Marker: `cross-server`

## Combat details

- [ ] **Boss wipe or reset** (pull, then run out or die). Markers: `pull` / `reset`
- [ ] **You die and get resurrected.** Markers: `died` / `rezzed`
- [ ] **A party member dies.** Marker: `ally died`
- [ ] **A/B gear test**: dummy 60 s, swap one Weapon Damage Boost line for a Damage Boost line, dummy 60 s again, same rotation. Markers: `A start` / `A end` / `B start` / `B end`
- [x] **Buffs**: use a potion, food and a scroll. Marker: name of each

## Pets (pet tracker)

- [x] **A pet soul drops.** Marker: `pet soul <pet name> <count before→after>`
- [x] **Black Cloud merchant**: open the Special and Pets tabs; buy and use one card if cheap. Marker: `merchant`

## World and timers

- [ ] **Daily reset**: be online across the reset and note the in-game time it happened. Marker: `daily reset`
- [ ] **Watcher Kaira** (or any fixed-time boss) spawns. Marker: `kaira spawn`
- [ ] **Tickets / energy**: open the ticket window; spend one entry. Marker: `ticket used`

## Setup variants

- [ ] **One session with ExitLag off** (to compare with ExitLag on). Note it in the recorder's notes
- [ ] **A friend playing a summon class** (Elementalist / Spiritmaster) records a dungeon run
- [ ] **Inspect** 2–3 players (view character). Marker: `inspect`

## Screenshots wanted (no recording needed)

Full screen, normal resolution, not cropped, meter hidden (tray → Hide overlay). Note your resolution and the game's UI scale.

**Hide in game menus**
- [ ] Inventory
- [ ] Character / stat info
- [ ] World map
- [ ] Skills
- [ ] Party finder
- [ ] Game settings
- [ ] A shop or merchant (Black Cloud)
- [ ] Any other window you often open (mail, pets, crafting…)
- [ ] One plain gameplay shot with no window open

**Field-boss timers**
- [ ] World map with the field-boss / timer panel visible
- [ ] One boss's timer tooltip or info

**Pet souls**
- [ ] Pet collection window, each tab or page
- [ ] Black Cloud merchant, Pets tab
